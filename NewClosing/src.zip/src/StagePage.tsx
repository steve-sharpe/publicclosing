import * as React from "react";
import { useState } from "react";

const COLUMN1 = [
  "Plumbing",
  "Lighting",
  "Cabinets",
  "Kitchen Plan",
  "Flooring",
  "Paint",
  "Foreman Selections",
  "Closets",
  "Deposit"
];

const COLUMN2 = [
  "Finance",
  "Deposit",
  "Permit",
  "NL Power"
];

export default function StagePage({
  jobId,
  stages,
  onClose,
  onSave
}: {
  jobId: string;
  stages: { [stage: string]: boolean | string };
  onClose: () => void;
  onSave: (jobId: string, stages: { [stage: string]: boolean | string }) => void;
}) {
  const PASSCODE = "42";
  const [localStages, setLocalStages] = useState<{ [stage: string]: boolean | string }>({
    ...stages,
    PermitNumber: typeof stages.PermitNumber === "string" ? stages.PermitNumber : ""
  });
  const [passcode, setPasscode] = useState("");
  const [error, setError] = useState("");

  const unlocked = passcode === PASSCODE;

  const handleChange = (stage: string) => {
    if (!unlocked) return;
    setLocalStages(prev => ({ ...prev, [stage]: !prev[stage] }));
  };

  const handlePermitNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!unlocked) return;
    const value = e.target.value.replace(/\D/g, "").slice(0, 12); // Only digits, max 12
    setLocalStages(prev => ({ ...prev, PermitNumber: value }));
  };

  const handlePasscodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPasscode(e.target.value);
    setError("");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!unlocked) {
      setError("Incorrect passcode.");
      return;
    }
    onSave(jobId, localStages);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-slate-900 text-slate-100 min-h-screen w-full">
      <form onSubmit={handleSubmit} className="flex flex-col h-full">
        <div className="flex justify-between items-center p-6 border-b border-slate-700">
          <h2 className="text-2xl font-bold">Track Stages</h2>
          <button type="button" onClick={onClose} className="px-4 py-2 rounded bg-slate-700 hover:bg-slate-800">Close</button>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="mb-6">
            <label className="block text-sm font-medium mb-1 text-slate-200">
              Enter 2-digit passcode to edit:
            </label>
            <input
              type="password"
              value={passcode}
              onChange={handlePasscodeChange}
              maxLength={2}
              className="w-20 rounded bg-slate-700 text-slate-100 px-2 py-1 border border-slate-600 focus:outline-none focus:ring-2 focus:ring-sky-500"
              autoFocus
            />
            {error && <div className="text-red-400 text-xs mt-1">{error}</div>}
          </div>
          <div className="w-full max-w-4xl grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* Column 1 */}
            <div className="flex flex-col gap-4">
              {COLUMN1.map(stage => (
                <label key={stage} className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={!!localStages[stage]}
                    onChange={() => handleChange(stage)}
                    className="accent-sky-500"
                    disabled={!unlocked}
                  />
                  <span className={unlocked ? "" : "text-slate-400"}>{stage}</span>
                </label>
              ))}
            </div>
            {/* Column 2 */}
            <div className="flex flex-col gap-4">
              {COLUMN2.map(stage =>
                stage === "Permit" ? (
                  <label key={stage} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={!!localStages[stage]}
                      onChange={() => handleChange(stage)}
                      className="accent-sky-500"
                      disabled={!unlocked}
                    />
                    <span className={unlocked ? "" : "text-slate-400"}>{stage}</span>
                    <input
                      type="text"
                      value={localStages.PermitNumber ?? ""}
                      onChange={handlePermitNumberChange}
                      className="ml-2 w-36 rounded bg-slate-700 text-slate-100 px-2 py-1 border border-slate-600"
                      disabled={!unlocked || !localStages[stage]}
                      placeholder="Permit #"
                      maxLength={12}
                    />
                  </label>
                ) : (
                  <label key={stage} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={!!localStages[stage]}
                      onChange={() => handleChange(stage)}
                      className="accent-sky-500"
                      disabled={!unlocked}
                    />
                    <span className={unlocked ? "" : "text-slate-400"}>{stage}</span>
                  </label>
                )
              )}
              {/* Two blank lines */}
              <div style={{ height: "2.5rem" }} />
              <div style={{ height: "2.5rem" }} />
            </div>
          </div>
        </div>
        <div className="flex justify-end gap-2 p-6 border-t border-slate-700">
          <button type="button" onClick={onClose} className="px-4 py-2 rounded bg-slate-700 hover:bg-slate-800">Cancel</button>
          <button type="submit" className="px-4 py-2 rounded bg-sky-600 text-white hover:bg-sky-700" disabled={!unlocked}>Save</button>
        </div>
      </form>
    </div>
  );
}